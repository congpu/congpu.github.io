#include <stdio.h>
int main()
{
  int var = 5;
  int ary[5] = {19, 10, 8, 17, 9}

  printf("var: %d\n", var);

  // Notice the use of & before var
  printf("address of var: %p", &var);  

  // Notice the use of & before var
  printf("ary[0]: %p", &ary[0]); 

  // Notice the use of & before var
  printf("ary[1]: %p", &ary[1]); 

  return 0;
}